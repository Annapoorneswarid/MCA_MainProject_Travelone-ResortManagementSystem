<?php include('include/header.php') ?>

 <!-- service page carousel  -->

<section class="white-section " id="testimonial-service">
<div id="testimonial-carousel" class="carousel slide" data-ride="false">
  <div class="carousel-inner">
    <div class="carousel-item active container-fluid">
      <h2 class="testimonial-text">We offers High-speed free Internet access both in the rooms and public areas</h2>
      <img class='testimonials-image' src="assets/picture/wifi.png" alt="dog-profile">
      <em>Free Wifi</em>
    </div>
    <div class="carousel-item container-fluid">
      <h2 class="testimonial-text">The resort restaurant with both indoor and outdoor seating offers an open-buffet breakfast </h2>
      <img class="testimonials-image" src="assets/picture/hot-cup.png" alt="lady-profile">
      <em>Breakfast & Tea</em>
    </div>
    
    <div class="carousel-item container-fluid">
      <h2 class="testimonial-text">We provide best laundry services to reduce customer works</h2>
      <img class="testimonials-image" src="assets/picture/laundry.png" alt="lady-profile">
      <em>Laundry Service</em>
    </div>
  </div>
  <a class="carousel-control-prev " href="#testimonial-carousel" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon icon-black"></span>
 
  </a>
  <a class="carousel-control-next text-dark" href="#testimonial-carousel" role="button" data-slide="next">
    <span class="carousel-control-next-icon icon-black"></span>
   
  </a>
</div>
</div>
</section>



      

<?php include('include/footer.html')?>