<?php include('include/header.php') ?>

        

<section id="gallery" class="p-5">
<h1 class="ml-5 mb-3 font-weight-bold text-dark">Making Memories..</h1>
  <div class="container">
    <div class="row">
    <div class="col-lg-4 mb-4">
    <div class="card">
    <img class="card-img-top"
            src="assets/picture/t1.jpg" alt="Card image cap"  height="240" >
      <div class="card-body">
        <h5 class="card-title">Kochi</h5>
        
        <a href="./Login/login.php" class="btn btn-outline-success btn-sm">Book</a>
        
      </div>
     </div>
    </div>


  <div class="col-lg-4 mb-4">
  <div class="card">
  <img class="card-img-top"
            src="assets/picture/t2.jpg" alt="Card image cap"  height="240" >
      <div class="card-body">
        <h5 class="card-title">Thrissur</h5>
       
<a href="./Login/login.php" class="btn btn-outline-success btn-sm">Book</a>
        
      </div>
      </div>
    </div>
    <div class="col-lg-4 mb-4">
  <div class="card">
  <img class="card-img-top"
            src="assets/picture/t3.jpg" alt="Card image cap"  height="240" >
      <div class="card-body">
        <h5 class="card-title">Idukki</h5>
       
<a href="./Login/login.php" class="btn btn-outline-success btn-sm">Book</a>
        
      </div>
      </div>
    </div>
    <div class="col-lg-4 mb-4">
  <div class="card">
  <img class="card-img-top"
            src="assets/picture/t4.jpg" alt="Card image cap"  height="240" >
      <div class="card-body">
        <h5 class="card-title">Kozhikkod</h5>
       
<a href="./Login/login.php" class="btn btn-outline-success btn-sm">Book</a>
        
      </div>
      </div>
    </div>
    <div class="col-lg-4 mb-4">
  <div class="card">
  <img class="card-img-top"
            src="assets/picture/t5.jpg" alt="Card image cap"  height="240" >
      <div class="card-body">
        <h5 class="card-title">Wayanad</h5>
       
<a href="./Login/login.php" class="btn btn-outline-success btn-sm">Book</a>
        
      </div>
      </div>
    </div>


    <div class="col-lg-4 mb-4">
    <div class="card">
    <img class="card-img-top"
            src="assets/picture/t6.jpg"  height="240" >
      <div class="card-body">
        <h5 class="card-title">Kollam</h5>
        
       <a href="./Login/login.php" class="btn btn-outline-success btn-sm">Book</a>
        
      </div>
     </div>
    </div>
  </div>
</div>
</section>

<?php include('include/footer.html')?>