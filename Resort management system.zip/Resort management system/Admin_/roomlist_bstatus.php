<?php
include('admin_header.php');
include('../include/dbConnect.php');
$rid=$_GET['sid'];
$sql=mysqli_query($con,"SELECT * FROM `room_list` WHERE `RoomId`='$rid'"); 
$rows=mysqli_fetch_array($sql); 
$status=$rows['Booking_status'];
if($status=='Available')
{
    $sql1=mysqli_query($con,"UPDATE `room_list` SET `Booking_status`='Booked' WHERE  `RoomId`='$rid'"); 
    echo "<script> window.location.href='roomlist.php';</script>";
}
elseif($status=='Booked')
{
    $sql2=mysqli_query($con,"UPDATE `room_list` SET `Booking_status`='Available' WHERE  `RoomId`='$rid'"); 
    echo "<script> window.location.href='roomlist.php';</script>";;
}

?>