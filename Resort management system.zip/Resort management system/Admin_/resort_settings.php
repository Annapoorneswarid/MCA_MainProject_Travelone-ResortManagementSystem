<?php include("admin_header.php"); 
include '../include/dbConnect.php';
$sql=mysqli_query($con,"SELECT * FROM `general_settings`");
$row=mysqli_fetch_array($sql);


if(isset($_POST['save'])){
    $companyname = mysqli_real_escape_string($con, $_POST['companyName']);
    $addr1 = mysqli_real_escape_string($con, $_POST['address1']);
    $addr2 = mysqli_real_escape_string($con, $_POST['address2']);
    $city = mysqli_real_escape_string($con, $_POST['city']);  
    $state = mysqli_real_escape_string($con, $_POST['state']);
    $country = mysqli_real_escape_string($con, $_POST['country']);
    $pin = mysqli_real_escape_string($con, $_POST['pin']);
    $description = mysqli_real_escape_string($con, $_POST['description']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phnno = mysqli_real_escape_string($con, $_POST['phoneNumber']);
    $teleno = mysqli_real_escape_string($con, $_POST['teleNumber']);
    $update=mysqli_query($con,"UPDATE `general_settings` SET `Address_line1`='$addr1',`Address_line2`='$addr2',`City`='$city',`State`='$state',`Country`='$country',`Zip_code`='$pin',`Email`='$email',
    `Phone_number`='$phnno',`Telephone_number`='$teleno',`Description`='$description'");
    echo "<script> alert('updated Successfully');window.location.href='resort_settings.php';</script>";
}
?>

<!-- Page Content  -->
<div id="content" class="p-4 p-md-5 pt-5">


<br>


 <!-- table for the display the content  -->
 <div class="container-fluid col-11" id="contentArea">
 <h4 class="mb-4 mt-5 ">Company Details</h4>

 <br>
 <div class="Message">
            
</div>
 <!-- update New User Form  -->
 <form id="gs_form" method="POST" action="" enctype="multipart/form-data" autocomplete="off">
 
                <div class="row">
                    <input type="hidden" id="gs_id" name="gs_id">

                    <!-- First Name -->
                    <div class="input-group col-lg-6 mb-4">
                    <div class="ml-2">
                         <label for="companyName">Company Name</label>
                     </div>
                     <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-user text-muted"></i>
                            </span>
                        </div>
                        <input id="companyName" type="text" name="companyName"  value="<?php echo $row['Name'];?>" class="form-control bg-white border-left-0 border-md" readonly  required>
                    </div>
                    </div>



                    <!-- Address -->
                    <div class="input-group col-lg-6 mb-4">
                    <div class="ml-2">
                         <label for="address1">Address Line 1</label>
                     </div>
                     <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-user text-muted"></i>
                            </span>
                        </div>
                        <input id="address1" type="text" name="address1"  value="<?php echo $row['Address_line1'];?>" class="form-control bg-white border-left-0 border-md" required>
                    </div>
                    </div>  
                    
                    <!-- Address -->
                    <div class="input-group col-lg-4 mb-4">
                    <div class="ml-2">
                         <label for="address2">Address Line 2</label>
                     </div>
                     <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-user text-muted"></i>
                            </span>
                        </div>
                        <input id="address2" type="text" name="address2" value="<?php echo $row['Address_line2'];?>" class="form-control bg-white border-left-0 border-md" required>
                    </div>
                    </div>
            <!-- Address -->
                    <div class="input-group col-lg-4 mb-4">
                    <div class="ml-2">
                         <label for="city">City</label>
                     </div>
                     <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-user text-muted"></i>
                            </span>
                        </div>
                        <input id="city" type="text" name="city" value="<?php echo $row['City'];?>" class="form-control bg-white border-left-0 border-md" required>
                    </div>
                    </div>
            <!-- Address -->
                    <div class="input-group col-lg-4 mb-4">
                    <div class="ml-2">
                         <label for="state">State</label>
                     </div>
                     <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-user text-muted"></i>
                            </span>
                        </div>
                        <input id="state" type="text" name="state" value="<?php echo $row['State'];?>"  readonly class="form-control bg-white border-left-0 border-md" required>
                    </div>
                    </div>
             <!-- Address -->
                    <div class="input-group col-lg-3 mb-4">
                    <div class="ml-2">
                         <label for="country">Country</label>
                     </div>
                     <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-user text-muted"></i>
                            </span>
                        </div>
                        <input id="country" type="text" name="country"  value="<?php echo $row['Country'];?>" readonly class="form-control bg-white border-left-0 border-md" required>
                    </div>
                    </div>
             <!-- Address -->
                    <div class="input-group col-lg-3 mb-4">
                    <div class="ml-2">
                         <label for="zip">Pin Code</label>
                     </div>
                     <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-user text-muted"></i>
                            </span>
                        </div>
                        <input id="zip" type="text" name="pin"  value="<?php echo $row['Zip_code'];?>" class="form-control bg-white border-left-0 border-md" required>
                    </div>
                    </div>
              <!-- description -->
                    <div class="input-group col-lg-6 mb-4">
                    <div class="ml-2">
                         <label for="description">Description</label>
                     </div>
                     <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-user text-muted"></i>
                            </span>
                        </div>
                        <input id="description" type="text" name="description" value="<?php echo $row['Description'];?>" class="form-control bg-white border-left-0 border-md" required>
                    </div>
                    </div>

                    <!-- second form   -->

                    <h4 class="mb-4 mt-5 ml-4">Contact Details</h4>
                    
                    <br>

                    <!-- Email Address -->
                    <div class="input-group col-lg-12 mb-4">
                    <div class="ml-2">
                         <label for="email">Email</label>
                     </div>
                     <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0" >
                                <i class="fa fa-envelope text-muted"></i>
                            </span>
                        </div>
                        <input id="email" type="email" name="email" value="<?php echo $row['Email'];?>" class="form-control bg-white border-left-0 border-md" required>
                    </div>
                    </div>
                  
                   
                    <!-- Phone Number -->
                    <div class="input-group col-lg-6 mb-4">
                    <div class="ml-2">
                         <label for="phoneNumber">Phone Number</label>
                     </div>
                     <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-phone-square text-muted"></i>
                            </span>
                        </div>
                       
                      
                        <input id="phoneNumber" type="tel" name="phoneNumber" value="<?php echo $row['Phone_number'];?>" pattern="[789][0-9]{9}" class="form-control bg-white border-md border-left-0 pl-3" required>
                    </div>
                    </div>


                    <!-- Phone Number -->
                    <div class="input-group col-lg-6 mb-4">
                    <div class="ml-2">
                         <label for="teleNumber">Telephone Number</label>
                     </div>
                     <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-phone-square text-muted"></i>
                            </span>
                        </div>
                       
                      
                        <input id="teleNumber" type="tel" name="teleNumber"  value="<?php echo $row['Telephone_number'];?>" pattern="[0-9]{9}" class="form-control bg-white border-md border-left-0 pl-3" required>
                    </div>
                    </div>


                   
                    

          
                </div>
         
                <div class="form-group col-lg-6 mx-auto mb-0">
                        <button id="updateUser" type="submit" class="btn btn-primary btn-block py-2" name="save" >
                            <span class="font-weight-bold">Save Changes</span>
                        </button>
                    </div>
               
            
        </form>
</div>
  <!-- end of container  -->

</div>
