<?php include('admin_header.php') ?>
<?php
include '../include/dbConnect.php';

	?>
<div id="content" class="p-4 p-md-5 pt-5">

<h2 class="mb-4">Rooms</h2>


<!-- Model For adding new User  -->

<!-- Button trigger modal -->


<main id="main" class="main">

        

    
            <div class="card-body">
            <style>
table, th, td {
  border:1px solid black;
}
</style>
<body>



<table style="width:100%">
<table border=3 width=70%>
  <tr>
    <th>Sl no.</th>
    <th>Room Type</th>
    <th>Cost</th>
    <th>Room No</th>
    <th>Status</th>
    <th>Booking Status</th>    
    <th>Action</th>
    
    
  </tr>
  <tbody>
      <?php
      $count=0;
      $query="SELECT * FROM `room_list`" ;
      $query_run = mysqli_query($con, $query);       
       while($row=mysqli_fetch_array( $query_run))
          {
            $rtype=$row['RoomTypeId'];
            $query = mysqli_query($con,"SELECT * FROM `room_type` WHERE `RoomTypeId`='$rtype'"); 
            $row1=mysqli_fetch_array( $query);
            $count++;
            
              ?>
             <tr>
              <td><?php echo $count; ?></td>
              <td><?= $row1['RoomType']; ?></td>
              <td><?= $row1['Cost']; ?></td>
              
              <td><?= $row['RoomNumber']; ?></td>
              
              <td><?= $row['Status']; ?></td>
              <td><?= $row['Booking_status']; ?></td>

              <td><a href="roomlist_bstatus.php?sid=<?php echo $row['RoomId']; ?>" onclick="return confirm('Mark as confirmed??')"><button type="button" class="btn btn-success">BookingStatus</button></a>
                 <a href="delete_roomlist.php?sid=<?php echo $row['RoomId']; ?>" onclick="return confirm('Mark as Delete??')"><button type="button" class="btn btn-danger">Delete</button></a>
                 <a href="roomlist_status.php?sid=<?php echo $row['RoomId']; ?>" onclick="return confirm('Mark as confirmed??')"><button type="button" class="btn btn-primary">Status</button></a></td>
              
              
              
    
             </tr>
              <?php

          

      }
      


      ?>
      <style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #867198;
    color: white;
}
</style>
      
  </tbody>
</table>
        
    </div>
</div>


