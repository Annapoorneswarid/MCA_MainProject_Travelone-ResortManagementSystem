<?php
include('admin_header.php');
include('../include/dbConnect.php');
$rid=$_GET['sid'];
$sql=mysqli_query($con," DELETE FROM `event_list` WHERE `EventId`='$rid'"); 
echo "<script> window.location.href='eventlist.php';</script>";

?>