<?php
include('admin_header.php');
include('../include/dbConnect.php');
$rid=$_GET['sid'];
$sql=mysqli_query($con," DELETE FROM `feedback` WHERE `FeedbackId`='$rid'"); 
echo "<script> window.location.href='feedback.php';</script>";

?>