<?php
session_start();
include('../include/dbconnect.php');

$id=$_GET['cid'];
$result=mysqli_query($con,"SELECT `BookingId`, `RoomId`, `User_id`, `Date`, `CheckIn`, `CheckOut`, `NoOfGuest`, `Room_Number`, `Amount`, `Email`, `Phone_number`, `Status` FROM `room_book` WHERE User_id=$id ") or die(mysqli_error($con));




include('pdf_mc_table.php');
$pdf = new PDF_MC_TABLE();
$pdf->AddPage();
$pdf->SetFont('Arial','B',15);	
$pdf->Cell(176, 5, 'TravelOne - Resort Management System ', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();	
$row=mysqli_fetch_array($result);
$id=$row['User_id'];
  $result2=mysqli_query($con,"SELECT * FROM `users_details` WHERE  `UserId`='$id'");
  $row2=mysqli_fetch_array($result2);
  $id=$row['RoomId'];
  $result3=mysqli_query($con,"SELECT * FROM `room_type` WHERE  `RoomTypeId`='$id'");
  $row3=mysqli_fetch_array($result3);
$pdf->SetFont('Arial','',12);	


$pdf->Cell(0,12,'Name : '. $row2['FirstName']." ".$row2['LastName'],0,1); 
// $image1 = "img/*.jpg";
// // $this->Cell( 40, 40, $pdf->Image($image1, $pdf->GetX(), $pdf->GetY(), 33.78), 0, 0, 'L', false );
// $pdf-> Image('img/'.$image1,100,15,35,35);
$pdf->Cell(0,12,'Email : '. $row2['Email'],0,1);
$pdf->Cell(0,12,'Contact No : '. $row2['ContactNo'],0,1);
$pdf->Ln();	

$pdf->Cell(0,12,'Room Type : '. $row3['RoomType'],0,1);

$pdf -> Line(12, 70, 180,71);
$pdf->Cell(0,12,'Room Number :'. $row['Room_Number'],0,1);
$pdf->Cell(0,12,'Checkin Date : '. $row['CheckIn'],0,1);
$pdf->Cell(0,12,'CheckOut Date: '. $row['CheckOut'],0,1);
$pdf->Cell(0,12,'Total Amount : '. $row['Amount'],0,1);
$pdf->Cell(0,12,'Booking Status : '. $row['Status'],0,1);






$pdf->Output();
?>