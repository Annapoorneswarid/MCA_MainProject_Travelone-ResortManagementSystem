<?php
include('admin_header.php');
include('../include/dbConnect.php');
$rid=$_GET['sid'];
$sql=mysqli_query($con,"SELECT * FROM `event_list` WHERE `EventId`='$rid'"); 
$rows=mysqli_fetch_array($sql); 
$status=$rows['Booking_status'];
if($status=='Available')
{
    $sql1=mysqli_query($con,"UPDATE `event_list` SET `Booking_status`='Booked' WHERE  `EventId`='$rid'"); 
    echo "<script> window.location.href='eventlist.php';</script>";
}
elseif($status=='Booked')
{
    $sql2=mysqli_query($con,"UPDATE `event_list` SET `Booking_status`='Available' WHERE  `EventId`='$rid'"); 
    echo "<script> window.location.href='eventlist.php';</script>";;

}


?>