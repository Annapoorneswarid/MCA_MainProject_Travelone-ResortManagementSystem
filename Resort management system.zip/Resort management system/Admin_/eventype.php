<?php include('admin_header.php') ?>
<?php
include '../include/dbConnect.php';

	?>
<div id="content" class="p-4 p-md-5 pt-5">

<h2 class="mb-4">Event Type</h2>
<!-- Button trigger modal -->
<a href="addeventtype.php">
<button type="button" class="btn btn-dark" id="addeventBtn">
<i class="fa fa-user-plus" aria-hidden="true"></i>  Add New Event Type
</button></a>

<main id="main" class="main">

        

    
            <div class="card-body">
            <style>
table, th, td {
  border:1px solid black;
}
</style>
<body>



<table style="width:100%">
<table border=3 width=70%>
  <tr>
    <th>Sl no.</th>
    <th>Event Type</th>
    <th>Image</th>
    <th>Description</th>
    <th>Cost</th>
    <th>Status</th>
    <th>Action</th>
    
    
  </tr>
  <tbody>
      <?php
      $count=0;
      $query="SELECT * FROM `event_type`" ;
      $query_run = mysqli_query($con, $query);       
       while($row=mysqli_fetch_array( $query_run))
          {
            $count++;
            
              ?>
             <tr>
              <td><?php echo $count; ?></td>
              <td><?= $row['EventType']; ?></td>
              <td><img src="../assets/picture/EventType/<?php echo $row['EventImage'];?>" style="width:150px; height:100px;"/></td>
              <td><?= $row['Description']; ?></td>
              <td><?= $row['Cost']; ?></td>
              <td><?= $row['Status']; ?></td>
              <td><a href="edit_eventtype.php?sid=<?php echo $row['EventTypeId']; ?>"><button type="button" class="btn btn-success">Edit</button></a>
                 <a href="delete_event.php?sid=<?php echo $row['EventTypeId']; ?>" onclick="return confirm('Mark as Delete??')"><button type="button" class="btn btn-danger">Delete</button></a>
                 <a href="event_status.php?sid=<?php echo $row['EventTypeId']; ?>" onclick="return confirm('Mark as confirmed??')"><button type="button" class="btn btn-primary">Status</button></a></td>
              
    
             </tr>
              <?php

          

      }
      


      ?>
      <style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #867198;
    color: white;
}
</style>
      
  </tbody>
</table>
        
    </div>
</div>
