<?php
include('admin_header.php');
include('../include/dbConnect.php');
$rid=$_GET['sid'];
$sql=mysqli_query($con,"SELECT * FROM `room_type` WHERE `RoomTypeId`='$rid'"); 
$rows=mysqli_fetch_array($sql); 
$status=$rows['Status'];
if($status=='active')
{
    $sql1=mysqli_query($con,"UPDATE `room_type` SET `Status`='in-active' WHERE  `RoomTypeId`='$rid'"); 
    echo "<script> window.location.href='roomtype.php';</script>";
}
elseif($status=='in-active')
{
    $sql2=mysqli_query($con,"UPDATE `room_type` SET `Status`='active' WHERE  `RoomTypeId`='$rid'");
    echo "<script> window.location.href='roomtype.php';</script>";
}

?>