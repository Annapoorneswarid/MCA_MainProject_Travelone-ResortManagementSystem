<?php
include '../include/dbConnect.php';
$id=$_GET['sid'];
$Sql=mysqli_query($con,"DELETE FROM `users_details` WHERE `UserId`='$id'");
header("location:user.php");
?>