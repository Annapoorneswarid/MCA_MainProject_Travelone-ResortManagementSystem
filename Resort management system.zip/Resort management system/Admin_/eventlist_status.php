<?php
include('admin_header.php');
include('../include/dbConnect.php');
$rid=$_GET['sid'];
$sql=mysqli_query($con,"SELECT * FROM `event_list` WHERE `EventId`='$rid'"); 
$rows=mysqli_fetch_array($sql); 
$status=$rows['Status'];
if($status=='active')
{
    $sql1=mysqli_query($con,"UPDATE `event_list` SET `Status`='in-active' WHERE  `EventId`='$rid'"); 
    echo "<script> window.location.href='eventlist.php';</script>";
}
elseif($status=='in-active')
{
    $sql2=mysqli_query($con,"UPDATE `event_list` SET `Status`='active' WHERE  `EventId`='$rid'"); 
    echo "<script> window.location.href='eventlist.php';</script>";
}


?>