<?php
include('admin_header.php');
include('../include/dbConnect.php');
$rid=$_GET['sid'];
$sql=mysqli_query($con," DELETE FROM `room_type` WHERE `RoomTypeId`='$rid'"); 
echo "<script> window.location.href='roomtype.php';</script>";

?>