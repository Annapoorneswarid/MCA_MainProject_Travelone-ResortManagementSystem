<?php include('admin_header.php');
include('../include/dbConnect.php');

if(isset($_POST['add_foodtype'])){
    $foodtype = mysqli_real_escape_string($con, $_POST['FoodTypeName']);
    $cost = mysqli_real_escape_string($con, $_POST['cost']);
    $description = mysqli_real_escape_string($con, $_POST['description']);


    $FoodImageName = $_FILES["FoodImage"]["name"];
    $tempname = $_FILES["FoodImage"]["tmp_name"];   
    $folder = "../assets/picture/FoodType/".$FoodImageName;

    $insert="insert into `food_type`(`FoodType`, `FoodImage`, `Description`, `Cost`, `Status`) values('$foodtype','$FoodImageName','$description','$cost','active') " ;

                    if(mysqli_query($con,$insert))
                    {
                        if(!move_uploaded_file($tempname, $folder)){
                            $error ="Error in Registration ...! Try after sometime";
                            error("addfoodtype.php",$error);
                        }
                    }
                    else{
                          $error ="Error in Registration ...! Try after sometime";
                          error("foodtype.php",$error);

                  }

}



?>





<br><br>
<center><h2>Add New Food Package</h2></center>
<div class="container">
    <div class="row align-items-center my-5">
        
        <center><div class="col-md-7 col-lg-6 ml-auto">
            <form action="" method="POST" enctype="multipart/form-data" autocomplete="off">
                <div class="row">
                        <div class="container mb-4">
                            <div class="picture-container">
                                <div class="picture">
                                <img src="assets/picture/user.png" class="picture-src" id="wizardPicturePreview" title="">
                                <input type="file" id="wizard-picture" class="" name="FoodImage" required>
                            </div>
                        <h6 class="">Choose Picture</h6>
                        
                    </div>
                   
                </div>
               

                    
                    <div class="input-group col-lg-6 mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-user text-muted"></i>
                            </span>
                        </div>
                        <input id="FoodTypeName" type="text" name="FoodTypeName" placeholder="Food Package Name" class="form-control bg-white border-left-0 border-md" required>
                    </div>

                    

                    
                    <div class="input-group col-lg-12 mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0" >
                                <i class="fa fa-black-tie text-muted"></i>
                            </span>
                        </div>
                        <input id="Cost" type="text" name="cost" placeholder="Cost" class="form-control bg-white border-left-0 border-md" required>
                    </div>
                   
                    
                    <div class="input-group col-lg-12 mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-black-tie text-muted"></i>
                            </span>
                        </div>
                      
                        <input id="Description" type="text" name="description"  placeholder="Description" class="form-control bg-white border-md border-left-0 pl-3" required>
                    </div>


                    
                    
                    <div class="form-group col-lg-12 mx-auto mb-0">
                        <button type="submit" class="btn btn-primary btn-block py-2" name="add_foodtype" >
                            <span class="font-weight-bold">Add</span>
                        </button>
                        
                    </div>

                    
                    <div class="text-center w-100">
                        <p class="text-muted font-weight-bold"> <a href="foodtype.php" class="text-primary ml-2">Cancel</a></p>
                    </div>
                    
                    
                    
                    

                </div>
                </form>
        </div></center>
    </div>
</div>


