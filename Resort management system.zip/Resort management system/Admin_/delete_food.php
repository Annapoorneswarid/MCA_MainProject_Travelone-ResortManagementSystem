<?php
include('admin_header.php');
include('../include/dbConnect.php');
$fid=$_GET['sid'];
$sql=mysqli_query($con," DELETE FROM `food_type` WHERE `FoodTypeId`='$fid'"); 
echo "<script> window.location.href='foodtype.php';</script>";

?>