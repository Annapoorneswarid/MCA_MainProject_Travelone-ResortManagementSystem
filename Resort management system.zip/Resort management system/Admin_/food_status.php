<?php
include('admin_header.php');
include('../include/dbConnect.php');
$rid=$_GET['sid'];
$sql=mysqli_query($con,"SELECT * FROM `food_type` WHERE `FoodTypeId`='$rid'"); 
$rows=mysqli_fetch_array($sql); 
$status=$rows['Status'];
if($status=='active')
{
    $sql1=mysqli_query($con,"UPDATE `food_type` SET `Status`='in-active' WHERE  `FoodTypeId`='$rid'"); 
    echo "<script> window.location.href='foodtype.php';</script>";
}
elseif($status=='in-active')
{
    $sql2=mysqli_query($con,"UPDATE `food_type` SET `Status`='active' WHERE  `FoodTypeId`='$rid'"); 
    echo "<script> window.location.href='foodtype.php';</script>";
}


?>