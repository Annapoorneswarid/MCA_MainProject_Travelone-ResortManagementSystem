<?php
include('admin_header.php');
include('../include/dbConnect.php');
$rid=$_GET['sid'];
$sql=mysqli_query($con," DELETE FROM `travel_package` WHERE `TravelPackageId`='$rid'"); 
echo "<script> window.location.href='travel.php';</script>";

?>