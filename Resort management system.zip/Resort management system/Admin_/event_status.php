<?php
include('admin_header.php');
include('../include/dbConnect.php');
$eid=$_GET['sid'];
$sql=mysqli_query($con,"SELECT * FROM `event_type` WHERE `EventTypeId`='$eid'"); 
$rows=mysqli_fetch_array($sql); 
$status=$rows['Status'];
if($status=='active')
{
    $sql1=mysqli_query($con,"UPDATE `event_type` SET `Status`='in-active' WHERE  `EventTypeId`='$eid'"); 
    echo "<script> window.location.href='eventype.php';</script>";
}
elseif($status=='in-active')
{
    $sql2=mysqli_query($con,"UPDATE `event_type` SET `Status`='active' WHERE  `EventTypeId`='$eid'"); 
    echo "<script> window.location.href='eventype.php';</script>";;
}

?>