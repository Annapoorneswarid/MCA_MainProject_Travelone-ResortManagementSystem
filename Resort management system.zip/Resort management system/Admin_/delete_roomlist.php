<?php
include('admin_header.php');
include('../include/dbConnect.php');
$rid=$_GET['sid'];
$sql=mysqli_query($con," DELETE FROM `room_list` WHERE `RoomId`='$rid'"); 
echo "<script> window.location.href='roomlist.php';</script>";

?>