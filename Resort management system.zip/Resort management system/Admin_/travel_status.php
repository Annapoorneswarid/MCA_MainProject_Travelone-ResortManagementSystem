<?php
include('admin_header.php');
include('../include/dbConnect.php');
$rid=$_GET['sid'];
$sql=mysqli_query($con,"SELECT * FROM `travel_package` WHERE `TravelPackageId`='$rid'"); 
$rows=mysqli_fetch_array($sql); 
$status=$rows['Status'];
if($status=='active')
{
    $sql1=mysqli_query($con,"UPDATE `travel_package` SET `Status`='in-active' WHERE  `TravelPackageId`='$rid'"); 
    echo "<script> window.location.href='travel.php';</script>";
}
elseif($status=='in-active')
{
    $sql2=mysqli_query($con,"UPDATE `travel_package` SET `Status`='active' WHERE  `TravelPackageId`='$rid'"); 
    echo "<script> window.location.href='travel.php';</script>";
}


?>