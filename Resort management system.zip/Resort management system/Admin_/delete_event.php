<?php
include('admin_header.php');
include('../include/dbConnect.php');
$eid=$_GET['sid'];
$sql=mysqli_query($con," DELETE FROM `event_type` WHERE `EventTypeId`='$eid'"); 
echo "<script> window.location.href='eventype.php';</script>";

?>