<?php include('admin_header.php') ?>
<?php
include '../include/dbConnect.php';

	?>
<div id="content" class="p-4 p-md-5 pt-5">

<h2 class="mb-4"> Travel Packages</h2>
<!-- Button trigger modal -->
<a href="addtravelpackage.php">
<button type="button" class="btn btn-dark" id="addtravelBtn">
<i class="fa fa-user-plus" aria-hidden="true"></i>  Add New Travel Package
</button></a>

<main id="main" class="main">

        

    
            <div class="card-body">
            <style>
table, th, td {
  border:1px solid black;
}
</style>
<body>



<table style="width:100%">
<table border=3 width=70%>
  <tr>
    <th>Sl no.</th>
    <th>Travel Destination</th>
    <th>Image</th>
    <th>Description</th>
    <th>Cost</th>
    <th>Status</th>
    <th>Action</th>
    
    
  </tr>
  <tbody>
      <?php
      $count=0;
      $query="SELECT * FROM `travel_package`" ;
      $query_run = mysqli_query($con, $query);       
       while($row=mysqli_fetch_array( $query_run))
          {
            $count++;
            
              ?>
             <tr>
              <td><?php echo $count; ?></td>
              <td><?= $row['TravelPackage']; ?></td>
              <td><img src="../assets/picture/Travel/<?php echo $row['TravelPlaceImage'];?>" style="width:150px; height:100px;"/></td>
              <td><?= $row['Description']; ?></td>
              <td><?= $row['Cost']; ?></td>
              <td><?= $row['Status']; ?></td>
              <td><a href="edit_travelpackage.php?sid=<?php echo $row['TravelPackageId']; ?>"><button type="button" class="btn btn-success">Edit</button></a>
                 <a href="delete_travel.php?sid=<?php echo $row['TravelPackageId']; ?>" onclick="return confirm('Mark as Delete??')"><button type="button" class="btn btn-danger">Delete</button></a>
                 <a href="travel_status.php?sid=<?php echo $row['TravelPackageId']; ?>" onclick="return confirm('Mark as confirmed??')"><button type="button" class="btn btn-primary">Status</button></a></td>
              
    
             </tr>
              <?php

          

      }
      


      ?>
      <style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #867198;
    color: white;
}
</style>
      
  </tbody>
</table>
        
    </div>
</div>
