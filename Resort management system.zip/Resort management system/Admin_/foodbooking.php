<?php include('admin_header.php');
include('../include/dbconnect.php');
?>
<div id="content" class="p-4 p-md-5 pt-5">

<h2 class="mb-4">Food Bookings</h2>

<main id="main" class="main">

        

    
            <div class="card-body">
            <style>
table, th, td {
  border:1px solid black;
}
</style>
<body>



<table style="width:100%">
<table border=3 width=70%>
  <tr>
    <th>Sl no.</th>
    <th>User</th>
    <th>Food Type</th>
    <th>Booked Date</th>
    <th>Serving Date</th>
    <th>Serving Time</th>
    <th>Number of Package</th>
    <th>Amount</th>
    <th>Status</th>
    <th>Details</th>
    

    
    
  </tr>
  <tbody>
      <?php
      $count=0;
      $query="SELECT * FROM `food_booking`" ;
      $query_run = mysqli_query($con, $query);       
       while($row=mysqli_fetch_array( $query_run))
          {
            $ftype=$row['FoodTypeId'];
            $query1 = mysqli_query($con,"SELECT * FROM `food_type` WHERE  `FoodTypeId`='$ftype'"); 
            $row1=mysqli_fetch_array( $query1);
            $uid=$row['UserId'];
            $query2= mysqli_query($con,"SELECT * FROM `users_details` WHERE  `UserId`='$uid'"); 
            $row2=mysqli_fetch_array( $query2);
            $count++; 

              ?>
             <tr>
              <td><?php echo $count; ?></td>
              <td><?php echo $row2['FirstName'];?>&nbsp<?php echo $row2['LastName']; ?></td>
             
              <td><?= $row1['FoodType']; ?></td>
              <td><?= $row['BookedDate']; ?></td>
              <td><?= $row['Date']; ?></td>            
              <td><?= $row['time']; ?></td>
              <td><?= $row['NoOfPackage']; ?></td>
              <td><?= $row['Amount']; ?></td>
              <td><?= $row['Status']; ?></td>
              <td>
                <a href="foodbill.php?cid=<?php echo $row['UserId'];?> "><button type="button" class="btn btn-success">Bill</button>
              </a></td>

              

              
    
             </tr>
              <?php
      }
      


      ?>
      <style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #867198;
    color: white;
}
</style>
      
  </tbody>
</table>
        
    </div>
</div>

