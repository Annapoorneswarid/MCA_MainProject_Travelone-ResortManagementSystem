<?php 
include 'admin_header.php';
include '../include/dbConnect.php';

	?>

<div id="content" class="p-4 p-md-5 pt-5">

<h2 class="mb-4">Users Details</h2>




<main id="main" class="main">

        

    
            <div class="card-body">
            <style>
table, th, td {
  border:1px solid black;
}
</style>
<body>



<table style="width:100%">
<table border=3 width=70%>
  <tr>
    <th>Sl no.</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Email</th>
    <th>Password</th>
    <th>Phone No</th>
    <th>Gender</th>
   
    
    <th>Image</th>
    <th>Status</th>
    <th>Action</th>

    <th>Registered Date/Time</th>
    
  </tr>
  <tbody>
      <?php
      $count=0;
      $query="SELECT * FROM `users_details` where role='user'" ;
      $query_run = mysqli_query($con, $query);
       
       while($row=mysqli_fetch_array( $query_run))
          {
            $count++;
            
              ?>
             <tr>
              <td><?php echo $count; ?></td>
              <td><?= $row['FirstName']; ?></td>
              <td><?= $row['LastName']; ?></td>
              <td><?= $row['Email']; ?></td>
              <td><?= $row['Password']; ?></td>
              <td><?= $row['ContactNo']; ?></td>
              <td><?= $row['Gender']; ?></td>
              <td><img src="../assets/picture/ProfilePic/<?php echo $row['ProfileImage'];?>" style="width:150px; height:100px;"/></td>
              <td><?= $row['Status']; ?></td>
              <td><a href="mark_delete.php?sid=<?php echo $row['UserId']; ?>" onclick="return confirm('Mark as Delete??')"><button type="button" class="btn btn-danger">Delete</button></a></td>
              
              <td><?= $row['LoginTime']; ?></td>
              
    
             </tr>
              <?php

          

      }
      


      ?>
      <style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #867198;
    color: white;
}
</style>
      
  </tbody>
</table>
        
    </div>
</div>


