<?php include('include/header.php') ?>

        

<section id="gallery" class="p-5">
<h1 class="ml-5 mb-3 font-weight-bold text-dark">Delicious Food For You</h1>
  <div class="container">
    <div class="row">
    


  <div class="col-lg-4 mb-4">
  <div class="card">
  <img class="card-img-top"
            src="assets/picture/f1.jpg" alt="Card image cap"  height="240" >
      <div class="card-body">
        <h5 class="card-title">Breakfast</h5>
       
<a href="./Login/login.php" class="btn btn-outline-success btn-sm">Book</a>
        
      </div>
      </div>
    </div>
    <div class="col-lg-4 mb-4">
  <div class="card">
  <img class="card-img-top"
            src="assets/picture/f2.jpg" alt="Card image cap"  height="240" >
      <div class="card-body">
        <h5 class="card-title">Lunch</h5>
       
<a href="./Login/login.php" class="btn btn-outline-success btn-sm">Book</a>
        
      </div>
      </div>
    </div>
    <div class="col-lg-4 mb-4">
  <div class="card">
  <img class="card-img-top"
            src="assets/picture/f3.jpg" alt="Card image cap"  height="240" >
      <div class="card-body">
        <h5 class="card-title">Tea Time</h5>
       
<a href="./Login/login.php" class="btn btn-outline-success btn-sm">Book</a>
        
      </div>
      </div>
    </div>
    <div class="col-lg-4 mb-4">
  <div class="card">
  <img class="card-img-top"
            src="assets/picture/f4.jpg" alt="Card image cap"  height="240" >
      <div class="card-body">
        <h5 class="card-title">Dinner</h5>
       
<a href="./Login/login.php" class="btn btn-outline-success btn-sm">Book</a>
        
      </div>
      </div>
    </div>


    
  </div>
</div>
</section>

<?php include('include/footer.html')?>