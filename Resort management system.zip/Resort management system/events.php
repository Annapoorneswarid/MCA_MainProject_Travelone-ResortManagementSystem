<?php include('include/header.php') ?>

        

<section id="gallery" class="p-5">
<h1 class="ml-5 mb-3 font-weight-bold text-dark">Book Your Event Spot</h1>
  <div class="container">
    <div class="row">
    <div class="col-lg-4 mb-4">
    <div class="card">
    <img class="card-img-top"
            src="assets/picture/meeting.jpeg" alt="Card image cap"  height="240" >
      <div class="card-body">
        <h5 class="card-title">Meeting</h5>
        
        <a href="./Login/login.php" class="btn btn-outline-success btn-sm">Book</a>
        <!-- <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a> -->
      </div>
     </div>
    </div>
  <div class="col-lg-4 mb-4">
  <div class="card">
  <img class="card-img-top"
            src="assets/picture/events.jpeg" alt="Card image cap"  height="240" >
      <div class="card-body">
        <h5 class="card-title">Conference</h5>
       
<a href="./Login/login.php" class="btn btn-outline-success btn-sm">Book</a>
        <!-- <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a> -->
      </div>
      </div>
    </div>
    <div class="col-lg-4 mb-4">
    <div class="card">
    <img class="card-img-top"
            src="assets/picture/wedding.jpg"  height="240" >
      <div class="card-body">
        <h5 class="card-title">Wedding</h5>
        
       <a href="./Login/login.php" class="btn btn-outline-success btn-sm">Book</a>
        <!-- <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a> -->
      </div>
     </div>
    </div>
  </div>
</div>
</section>

<?php include('include/footer.html')?>