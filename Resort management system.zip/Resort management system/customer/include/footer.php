<section id="footer">
        
  <footer class="text-center text-lg-start bg-dark text-white">
     
      <section
        class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
        
        <div class="me-5 d-none d-lg-block">
          <span>Get connected with us on social networks:</span>
        </div>
        
      </section>
      
    
     
      <section class="sub-footer">
        <div class="container text-center text-md-start mt-5">
         
          <div class="row mt-3">
           
           
            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
              
              <h6 class="text-uppercase fw-bold mb-4">
                Useful Links
              </h6>
              <p>
                <a href="#!" class="text-reset">Terms & Conditions</a>
              </p>
              <p>
                <a href="#!" class="text-reset">Privacy and Policy</a>
              </p>
              
            </div>
            
           
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
             
              <h6 class="text-uppercase fw-bold mb-4">
                Contact
              </h6>
              <p><i class="fas fa-home me-3"></i>
                Travelone-Search your perfect destination,Kochi</p>
               <p>Country :India</p>
               <p>  Pin Code :680101</p>
              <p>
                <i class="fas fa-envelope me-3"></i>
                travelone@gmail.com
              </p>
              <p><i class="fas fa-phone me-3"></i>+91 9778347034</p>
              
            </div>
            
          </div>
          
        </div>
      </section>
      
      <div class="" style="background-color: rgba(86, 75, 86, 0.268);">
      Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved 
        
      </div>
     
    </footer>
    
    </section>
       
  
  
  
       </body>
  </html>
  
  