<?php
 include('include/header.php');
include('../include/dbConnect.php');

$id = $_SESSION['loggedUserId'];
if(isset($_POST['submit'])){
  $msg = mysqli_real_escape_string($con, $_POST['Message']);


  $insert=mysqli_query($con,"insert into `feedback`(`UserId`, `Message`)  values('$id','$msg')") ;
  echo "<script> alert('feedback has been sent'); window.location.href='index.php';</script>";

}
?>
<!DOCTYPE html>
<html>

<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
textarea {
  width: 200%;
  height: 250px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
}

.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  width:90px;
  height:30px:
 

}

.button2 {padding: 12px 28px;}
.center {
  margin-left: auto;
  margin-right: auto;
}

</style>
</head>
<body>



<center>
  <h2><b>FEEDBACK</b></h2>
  <br>
  <br>
</center>
  <center>
<div class="col-md-5 pr-lg-5 mb-5 mb-md-0">
            <img src="../assets/picture/L1.png" >
            
</div>
</center>
<br>
<br>

  
<center>
<div>
  <tr>
    <td> <form action="" method="post" >
      <table width ="100%" border="0" cellspacing="0" callpadding="0" class="">
        <tr>
          

<label>
  <textarea name="Message" id=feedback value="Message" placeholder="Write comments"></textarea>
</label>

</tr>
<td>&nbsp:</td>
<td>

<center><button class="button button2" type="submit" name="submit">Submit</button><center>
</td>
</div>
</center>
</body>
<br>
<br>
<br>


</html>


