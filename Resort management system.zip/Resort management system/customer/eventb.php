<?php 
include('include/header.php');
include('../include/dbconnect.php');
?>
<div id="content" class="p-4 p-md-5 pt-5">

<h2 class="mb-4">Event Bookings</h2>

<main id="main" class="main">

        

    
            <div class="card-body">
            <style>
table, th, td {
  border:1px solid black;
}
</style>
<body>



<table style="width:100%">
<table border=3 width=70%>
  <tr>
    <th>Sl no.</th>
    
    <th>Date</th>
    <th>Event Type</th>
    <th>Hall No.</th>
    
    <th>Amount</th>
    <th>Status</th>
    <th>Details</th>
    

    
    
  </tr>
  <tbody>
      <?php
      $count=0;
      $id= $_SESSION['loggedUserId'];
      $query="SELECT * FROM `event_book` where User_id=$id" ;
      $query_run = mysqli_query($con, $query);       
      while($row=mysqli_fetch_array( $query_run))
          {
            $etype=$row['EventId'];
            $query3 = mysqli_query($con,"SELECT * FROM `event_type` WHERE  `EventTypeId`='$etype'"); 
            $row3=mysqli_fetch_array( $query3);
            $uid=$row['User_id'];
            $query4= mysqli_query($con,"SELECT * FROM `users_details` WHERE  `UserId`='$uid'"); 
            $row4=mysqli_fetch_array( $query4);
            $count++; 

              ?>
             <tr>
              <td><?php echo $count; ?></td>
             
              <td><?= $row['Date']; ?></td>
              <td><?= $row3['EventType']; ?></td>
              <td><?= $row['Hall_Number']; ?></td>
             
              <td><?= $row['Amount']; ?></td>
              <td><?= $row['Status']; ?></td>
              <td><a href="cancelevent.php?cid=<?php echo $row['User_id'];?> "><button type="button" class="btn btn-success">Cancel</button></a></td>


              
    
             </tr>
              <?php
      }
      


      ?>
      <style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #867198;
    color: white;
}
</style>
      
  </tbody>
</table>
        
    </div>
</div>
