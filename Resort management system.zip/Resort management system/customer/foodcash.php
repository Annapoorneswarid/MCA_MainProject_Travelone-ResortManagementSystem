<?php include('include/header.php') ;
include('../include/dbConnect.php');
$userid= $_SESSION['loggedUserId'];
$rid=$_GET['id'];

$bid=$_GET['bid'];

$sql2="SELECT * from food_type INNER JOIN food_booking ON food_type.FoodTypeId=food_booking.FoodTypeId JOIN users_details ON users_details.UserId=food_booking.UserId WHERE food_booking.UserId=$userid AND food_type.FoodTypeId=$rid";

$query2=mysqli_query($con,$sql2);
while($row2=mysqli_fetch_array($query2))
{
  $pak=$row2['NoOfPackage'];
  $cost=$row2['Cost'];
  $total=$pak*$cost;
  $sqli=mysqli_query($con,"UPDATE `food_booking` SET `Amount`='$total' where `BookingId`='$bid'");

}

?>

<!-- total foodCost -->
                      <center><div class="form-group col-lg-6 mb-4">
                     <br><br>
                     <div class="ml-2">
                         <label for="foodCost"><h2><b>Total Cost </b></h2></label>
                     </div>
                    <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                            <i class="fa fa-inr"></i>
                            </span>
                        </div>
                        <input id="totalCost" type="text" name="totalCost" value="<?php echo $total ?>"  class="form-control bg-white" required readonly>
                    </div>
                    </div></center> 
     <?php
      $count=0;
      $query="SELECT * FROM `food_booking`" ;
      $query_run = mysqli_query($con, $query);  
      $row=mysqli_fetch_array( $query_run);     
       if($row)
          {
            $ftype=$row['FoodTypeId'];
            $query1 = mysqli_query($con,"SELECT * FROM `food_type` WHERE  `FoodTypeId`='$ftype'"); 
            $row1=mysqli_fetch_array( $query1);
            $uid=$row['UserId'];
            $query2= mysqli_query($con,"SELECT * FROM `users_details` WHERE  `UserId`='$uid'"); 
            $row2=mysqli_fetch_array( $query2);
            $count++; 

              ?>
                    <!-- Submit Button -->
                    
                    <center><button type="submit" class="btn btn-danger" name="bookRoom" >
                            <span class="font-weight-bold"><a href="payment.php?id=<?php echo $row['UserId'];?> ">Proceed To Payment</a></span>
                        </button></center><br><br>
                        
                
<?php
          }
          ?>