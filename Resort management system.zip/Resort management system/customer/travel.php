<?php include('include/header.php') ;
include('../include/dbConnect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<body>
<div class="container">
      <a class="navbar-brand "><b><h1>Travel Packages</h1></a></b>
</div>
<div class="row product-categorie-box">
    
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade show active" id="grid-view">
                                    <div class="row">
                                    <?php  
                                    $result = mysqli_query($con,"SELECT * FROM travel_package");
                                    while ($raw = mysqli_fetch_array($result)){ 
                                        ?>
                                        <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                                        <form method="post"  enctype="multipart/form-data" action="">
                                            <div class="products-single fix">
                                                <div class="box-img-hover">
                                                
                                                    <img src="../assets/picture/Travel/<?php echo $raw['TravelPlaceImage']; ?>" class="img-fluid" alt="Image" style="height: 200px;width: 900px;">
                                    
                                                </div>
                                                <div class="why-text">
                                                <h4 align="center"><?php echo $raw['TravelPackage']; ?></h4>
                                                <h4 align="center">Rs.<?php echo $raw['Cost']; ?></h4>
                                                <h6 align="center"><?php echo $raw['Description']; ?></h6>
                                                <h6 align="center"><?php echo $raw['Status']; ?></h6>
                                                <input type="hidden" name="productid" value="<?php echo $raw['TravelPackageId']; ?>"> 
                                                    <a class="nav-link"  href="travelbook.php?id=<?php echo $raw['TravelPackageId']; ?>" aria-selected="true" align="center">Book Now</a>
                                                
                                                </div>
                                            </div><br><br>
                                            </form>
                                        </div>
                                        <?php } ?>	
                                    </div>
                                </div>
                                
                                     
                             
                            </div>
                        </div>

</body>
</html>