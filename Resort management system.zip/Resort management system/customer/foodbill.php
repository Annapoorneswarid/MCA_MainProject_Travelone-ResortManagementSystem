<?php
session_start();
include('../include/dbconnect.php');

$id=$_GET['cid'];
$result=mysqli_query($con,"SELECT `BookingId`, `FoodTypeId`, `UserId`, `BookedDate`, `Date`, `time`, `Package`, `Amount`, `Email`, `PhoneNo`, `Status`, `NoOfPackage` FROM `food_booking` WHERE UserId=$id ") or die(mysqli_error($con));




include('pdf_mc_table.php');
$pdf = new PDF_MC_TABLE();
$pdf->AddPage();
$pdf->SetFont('Arial','B',15);	
$pdf->Cell(176, 5, 'TravelOne - Resort Management System ', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();	
$row=mysqli_fetch_array($result);
$id=$row['UserId'];
  $result2=mysqli_query($con,"SELECT * FROM `users_details` WHERE  `UserId`='$id'");
  $row2=mysqli_fetch_array($result2);
  $id=$row['FoodTypeId'];
  $result3=mysqli_query($con,"SELECT * FROM `food_type` WHERE  `FoodTypeId`='$id'");
  $row3=mysqli_fetch_array($result3);
$pdf->SetFont('Arial','',12);	


$pdf->Cell(0,12,'Name : '. $row2['FirstName']." ".$row2['LastName'],0,1); 
// $image1 = "img/*.jpg";
// // $this->Cell( 40, 40, $pdf->Image($image1, $pdf->GetX(), $pdf->GetY(), 33.78), 0, 0, 'L', false );
// $pdf-> Image('img/'.$image1,100,15,35,35);
$pdf->Cell(0,12,'Email : '. $row2['Email'],0,1);
$pdf->Cell(0,12,'Contact No : '. $row2['ContactNo'],0,1);
$pdf->Ln();	

$pdf->Cell(0,12,'Food Type : '. $row3['FoodType'],0,1);

$pdf -> Line(12, 70, 180,71);
$pdf->Cell(0,12,'No of package :'. $row['NoOfPackage'],0,1);
$pdf->Cell(0,12,' Date : '. $row['Date'],0,1);
$pdf->Cell(0,12,'Time: '. $row['time'],0,1);
$pdf->Cell(0,12,'Total Amount : '. $row['Amount'],0,1);
$pdf->Cell(0,12,'Booking Status : '. $row['Status'],0,1);
$pdf->Cell(0,12,'Payment Status : '. $row['Status'],0,1);





$pdf->Output();
?>