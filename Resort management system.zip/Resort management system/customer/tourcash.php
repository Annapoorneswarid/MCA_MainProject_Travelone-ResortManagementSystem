<?php include('include/header.php') ;
include('../include/dbConnect.php');
$userid= $_SESSION['loggedUserId'];
$rid=$_GET['id'];

$bid=$_GET['bid'];

$sql3="SELECT * from travel_package INNER JOIN travel_booking ON travel_package.TravelPackageId=travel_booking.TravelPackageId JOIN users_details ON users_details.UserId=travel_booking.UserId WHERE travel_booking.UserId=$userid AND travel_package.TravelPackageId=$rid";

$query3=mysqli_query($con,$sql3);
while($row3=mysqli_fetch_array($query3))
{
  $hrs=$row3['total_duration'];
  $cost=$row3['Cost'];
  $total=$hrs*$cost;
  $sqli=mysqli_query($con,"UPDATE `travel_booking` SET `Amount`='$total' where `BookingId`='$bid'");


}


?>

<!-- total roomCost -->
                      <center><div class="form-group col-lg-6 mb-4">
                     <br><br>
                     <div class="ml-2">
                         <label for="roomCost"><h2><b>Total Cost</b></h2></label>
                     </div>
                    <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                            <i class="fa fa-inr"></i>
                            </span>
                        </div>
                        <input id="totalCost" type="text" name="totalCost" value="<?php echo $total ?>"   class="form-control bg-white" required readonly>
                    </div>
                    </div></center> 

                    <!-- Submit Button -->
 <?php
      $count=0;
      $query="SELECT * FROM `travel_booking`" ;
      $query_run = mysqli_query($con, $query); 
      $row=mysqli_fetch_array( $query_run);       
       if($row)
          {
            $ttype=$row['TravelPackageId'];
            $query1 = mysqli_query($con,"SELECT * FROM `travel_package` WHERE  `TravelPackageId`='$ttype'"); 
            $row1=mysqli_fetch_array( $query1);
            $uid=$row['UserId'];
            $query2= mysqli_query($con,"SELECT * FROM `users_details` WHERE  `UserId`='$uid'"); 
            $row2=mysqli_fetch_array( $query2);
            $count++; 

              ?>
                    
                    <center><button type="submit" class="btn btn-danger" name="booktour" >
                            <span class="font-weight-bold"><a href="payment.php?id=<?php echo $row['UserId'];?> ">Proceed To Payment</a></span>
                        </button></center><br><br>
                        <center><a href="tourbill.php?cid=<?php echo $row['UserId'];?> "><button type="button" class="btn btn-success">Receipt</button></a></center>
                <?php
          }
          ?>
