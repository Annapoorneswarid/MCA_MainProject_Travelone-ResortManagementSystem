<?php include('include/header.php') ;
include('../include/dbConnect.php');
$foodid=$_GET['id'];
$userid= $_SESSION['loggedUserId'];
$sql=mysqli_query($con,"SELECT * FROM `food_type` WHERE `FoodTypeId`='$foodid'");

$rows=mysqli_fetch_array($sql);
$amount=$rows['Cost'];

if(isset($_POST['order'])){
    $email= mysqli_real_escape_string($con, $_POST['email']);
    $phn= mysqli_real_escape_string($con, $_POST['contactno']);
    $noofguest= mysqli_real_escape_string($con, $_POST['no_of_guest']);
    $date= mysqli_real_escape_string($con, $_POST['date']);
   
    $package= mysqli_real_escape_string($con, $_POST['foodpackage']);
    $time= mysqli_real_escape_string($con, $_POST['Time']);

   
    

    $food=mysqli_query($con,"INSERT INTO `food_booking`(`FoodTypeId`, `UserId`, `Date`,`time`, `Package`,`Email`, `PhoneNo`, `NoOfPackage`, `Status`) 
    VALUES  ('$foodid','$userid','$date','$time','$package',' $email','$phn',' $noofguest','Booked')");
     $z=mysqli_insert_id($con);
     

    if($food)
    {
     echo "<script>alert('Successfully Booked');window.location.href='foodcash.php?id=$foodid && cost=$amount && bid=$z';</script>";
    }
    
    

    }              

?>


<div class="container">
    <div class="row align-items-center my-5">
        <!-- For Demo Purpose -->
        <div class="col-md-5 pr-lg-5 mb-5 mb-md-0">
            <img src="../assets/picture/L1.png" alt="" class="img-fluid mb-3 d-none d-md-block">
            
        </div>

        <!-- Booking Form -->
        <div class="col-md-7 col-lg-6 ml-auto">
            <form action="" method="POST" enctype="multipart/form-data" autocomplete="off">
                <div class="row">
                    <div class="container mb-4">
                        <h2 class="text-center">Make Your Booking</h2>
                        

                    </div>

                    <input type = "hidden" name = "FoodTypeId"  />
            

                    
                    <div class="form-group col-lg-6 mb-4">
                     
                     <div class="ml-2">
                         <label for="foodType">Food Package</label>
                     </div>
                    <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                            
                            </span>
                        </div>
                        <input id="foodType" type="text" name="foodpackage"  value="<?php echo $rows['FoodType'];?>" class="form-control bg-white border-left-0 border-md" required readonly>
                    </div>
                    </div>

                    
                    <div class="form-group col-lg-6 mb-4">
                     
                     <div class="ml-2">
                         <label for="foodCost">Cost of Food Package/ per person</label>
                     </div>
                    <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                            <i class="fa fa-inr"></i>
                            </span>
                        </div>
                        <input id="foodCost" type="text"  name="foodCost" value="<?php echo $rows['Cost'];?>" class="form-control bg-white border-left-0 border-md" required readonly>
                    </div>
                    </div>

                    <!-- Email Address -->
                    <div class="form-group col-lg-12 mb-4">
                     
                     <div class="ml-2">
                         <label for="email">Enter Email Id</label>
                     </div>
                    <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0" >
                                <i class="fa fa-envelope text-muted"></i>
                            </span>
                        </div>
                        <input id="email" type="email" name="email" placeholder="Email Address" class="form-control bg-white border-left-0 border-md" required>
                    </div>
                    </div>
                   
                    <!-- Phone Number -->
                    <div class="form-group col-lg-12 mb-4">
                     
                     <div class="ml-2">
                         <label for="phoneNumber">Enter Phone Number</label>
                     </div>
                    <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-phone-square text-muted"></i>
                            </span>
                        </div>
                      
                        <input id="contactno" type="tel" name="contactno" pattern="[789][0-9]{9}" placeholder="Phone Number" class="form-control bg-white border-md border-left-0 pl-3" required>
                    </div>
                    </div>


                    <!-- number of guest -->
                    <div class="form-group col-lg-12 mb-4">
                     
                     <div class="ml-2">
                         <label for="no_of_guest">Number of Persons</label>
                     </div>
                    <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <i class="fa fa-black-tie text-muted"></i>
                            </span>
                        </div>
                        <select id="no_of_guest" name="no_of_guest" class="form-control custom-select bg-white border-left-0 border-md" required>
                            <option value="" selected="true" disabled="true">Choose number of persons</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="4">5</option>
                            <option value="4">6</option>
                            <option value="4">7</option>
                            <option value="4">8</option>
                            <option value="4">9</option>
                            <option value="4">10</option>
                        </select>
                    </div>
                    </div>
                  
                    <!--checkin -->
                    

                    <div class="form-group col-lg-6 mb-4">
                        <div class="ml-2">
                        <label for="date"> Date</label>
                        </div>
                        <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                            </span>
                        </div>
                       
                        <input id="date" type="date" name="date" placeholder=" Data" class="form-control bg-white " required>
                        </div>
                    </div>

                    <div class="form-group col-lg-6 mb-4">
                     
                    <div class="ml-2">
                        <label for="Time">Time</label>
                    </div>
                    <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                            </span>
                        </div>
                        <input id="tTime" type="time" name="Time" placeholder="Time" class="form-control bg-white " required>
                    </div>
                    </div>

                    <div class="form-group col-lg-12 mx-auto mb-0">
                        <button type="submit" class="btn btn-primary btn-block py-2" name="order" >
                            <span class="font-weight-bold">Book</span>
                        </button>
                    </div>


                </div>
                </form>
        </div>
    </div>
</div>
