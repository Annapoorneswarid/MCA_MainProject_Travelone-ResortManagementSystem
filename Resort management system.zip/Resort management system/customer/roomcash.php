<?php include('include/header.php') ;
include('../include/dbConnect.php');
$userid= $_SESSION['loggedUserId'];
error_reporting(0);
$rid=$_GET['id'];
$cash=$_GET['cost'];
$bid=$_GET['bid'];
$sql="SELECT * FROM room_type INNER JOIN room_book on room_type.RoomTypeId=room_book.User_id WHERE room_book.User_id=$userid and room_book.RoomId='$rid'";

$query=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($query))
{
    $In=$row['CheckIn'];
    $Out=$row['CheckOut'];
    $diff=strtotime($In)-strtotime($Out);
    $day=abs(round($diff/86400));
    $total=$day*$cash;
    $sqli=mysqli_query($con,"UPDATE `room_book` SET `Amount`='$total' where `BookingId`='$bid'");


}

?>

<!-- total roomCost -->
                      <center><div class="form-group col-lg-6 mb-4">
                     <br><br>
                     <div class="ml-2">
                         <label for="roomCost"><h2><b>Total Cost</b></h2></label>
                     </div>
                    <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                            <i class="fa fa-inr"></i>
                            </span>
                        </div>
                        <input id="totalCost" type="text" name="totalCost"  value="<?php echo $total ?>" class="form-control bg-white" required readonly>
                    </div>
                    </div></center> 

                    <!-- Submit Button -->

                    <?php
      $count=0;
      $query="SELECT * FROM `room_book`" ;
      $query_run = mysqli_query($con, $query);   
      $row=mysqli_fetch_array( $query_run);    
       if($row)
          {
            $rtype=$row['RoomId'];
            $query1 = mysqli_query($con,"SELECT * FROM `room_type` WHERE  `RoomTypeId`='$rtype'"); 
            $row1=mysqli_fetch_array( $query1);
            $uid=$row['User_id'];
            $query2= mysqli_query($con,"SELECT * FROM `users_details` WHERE  `UserId`='$uid'"); 
            $row2=mysqli_fetch_array( $query2);
            $count++; 

              ?>
                    
                        <center><button type="submit" class="btn btn-danger" name="bookRoom" >
                            <span class="font-weight-bold"><a href="paymentgateway.php?id=<?php echo $row['User_id'];?>&&bid=<?php echo $bid;?> ">Proceed To Payment</a></span>
                        </button></center><br><br>
                        
    <?php
      }
      ?>