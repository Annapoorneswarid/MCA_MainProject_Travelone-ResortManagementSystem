<?php
        
        include('include/header.php');
        include('../include/dbConnect.php');  
        $apiKey="rzp_test_MP5yO075uwbur1";                  
       
?>
<form><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_Jq7P7oKgYRuZXc" async> </script> </form>