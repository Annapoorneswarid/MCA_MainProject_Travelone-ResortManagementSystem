<?php include('include/header.php') ?>

<!-- About  -->
<section class="about-section bg-light p-5" >
  
            <div class="row">
                <div class="col-md-12 col-lg-6 col-sm-12 mt-4">
                    <h1 class="ml-5 mb-3 font-weight-bold text-dark">About Us</h1>
                    <p class="title-para ml-5">	Travelone Resort is the combination of innovative design and crafted luxury . 
                      Here, We Combine comfort, personalized service and exceptional values. The Travelone Resort offering so many Rooms, Gym Facilities and many more Facilities and it is ideally situated in Kochi – Kerala, Near Hill Garden, Airport Ringroad.</p>

                    <p class="title-para ml-5">Our purpose is to give our guests a complete experience and a perfect stay. Our staff to have a culture of mutual respect, trust and integrity. Travelone Resort is a place that is fun and filled with the unexpected. 
                      What we do is always authentic, honest and mindful that less is often so much more.</p>
                    
                </div>
                <div class="col-md-12 col-lg-6 col-sm-12 d-flex mt-4 pl-5">
                    <img width="400px" height="400px" src="../assets/picture/r1.jpg">
                </div>
            </div>
 </section>






 


<?php include('include/footer.php')?>