<?php include('include/header.php') ?>


  
  <section class="carousel-section" id="slider">   
   <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">       
       <div class="carousel-inner">
         <div class="carousel-item active">
           <img class="d-block w-100" src="../assets/picture/a1.jpg" >          
         </div>
       </div>
     </div>
   </section>

 
 <!-- Page Content -->

 <section class="py-5 white-section" id="introduction" >
   <div class="container">
     <h1 class="display-4 title">TravelOne, Kochi.</h1>
     
   </div>

   <div class="container"> 
       
           
     
           <p class="text-justify">Travelone Resort is the combination of innovative design and crafted luxury . 
            Here, We Combine comfort, personalized service and exceptional values.
             The Travelone Resort offering so many Rooms, Gym Facilities and many more Facilities and it is ideally situated in Kochi – Kerala, Near Hill Garden, Airport Ringroad.
               <br>
               Our purpose is to give our guests a complete experience and a perfect stay. Our staff to have a culture of mutual respect, trust and integrity. 
               Travelone Resort is a place that is fun and filled with the unexpected. 
               What we do is always authentic, honest and mindful that less is often so much more.</p>

               
      </div>   
   </section>    
   
    
    <?php include('include/footer.php') ?>