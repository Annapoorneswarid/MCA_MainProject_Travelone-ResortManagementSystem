<?php include('include/header.php');
include('../include/dbConnect.php');
?>


<!DOCTYPE html>
<html lang="en">
<head>
<body>

<div class="container">
<div class="main">

<form action="php_checkbox.php" method="post">
<label class="heading"></label><b><h1>Customize Your Bookings</h1></b><br><br>
<input type="checkbox" name="check_list[]" value="C/C++"><label><h4>Rooms Bookings</h4></label><br><br>
<input type="checkbox" name="check_list[]" value="Java"><label><h4>Events Bookings</h4></label><br><br>
<input type="checkbox" name="check_list[]" value="PHP"><label><h4>Food Bookings</h4></label><br><br>
<input type="checkbox" name="check_list[]" value="HTML/CSS"><label><h4>Travel Package Booking</h4></label><br><br>

<input type="submit" name="submit" Value="Submit"/>


</form>
</div>
</div>
</body>
</head>
</html>
