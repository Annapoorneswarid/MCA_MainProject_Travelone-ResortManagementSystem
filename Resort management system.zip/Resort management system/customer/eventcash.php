<?php include('include/header.php') ;
include('../include/dbConnect.php');
$userid= $_SESSION['loggedUserId'];
$rid=$_GET['id'];

$bid=$_GET['bid'];

$sql5="SELECT * from event_type INNER JOIN event_book ON event_type.EventTypeId=event_book.EventId JOIN users_details ON users_details.UserId=event_book.User_id WHERE event_book.User_id=$userid AND event_type.EventTypeId=$rid;";

$query5=mysqli_query($con,$sql5);
while($row5=mysqli_fetch_array($query5))
{
  $hrs=$row5['hours'];
  $cost=$row5['Cost'];
  $total=$hrs*$cost;
  $sqli=mysqli_query($con,"UPDATE `event_book` SET `Amount`='$total' where `BookingId`='$bid'");


}



?>

<!-- total roomCost -->
                      <center><div class="form-group col-lg-6 mb-4">
                     <br><br>
                     <div class="ml-2">
                         <label for="roomCost"><h2><b>Total Cost</b></h2></label>
                     </div>
                    <div class="input-group ">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                            <i class="fa fa-inr"></i>
                            </span>
                        </div>
                        <input id="totalCost" type="text" name="totalCost"  value="<?php echo $total ?>" class="form-control bg-white" required readonly>
                    </div>
                    </div></center> 


                    <!-- Submit Button -->
                    
                    <center><button type="submit" class="btn btn-danger" name="bookRoom" >
                            <span class="font-weight-bold"><a href="payment.php?id=<?php echo $row['UserId'];?> ">Proceed To Payment</a></span>
                        </button></center><br><br>
  