<?php
session_start();
 include('../include/dbConnect.php');
 
 if(isset($_SESSION['loggedUserId']))
{
 
    $id= $_SESSION['loggedUserId'];
    $query="SELECT * FROM room_book where User_id ='$id'";
    $res = mysqli_query($con,$query);
    $r=mysqli_fetch_array($res);
    
    
      $query1="SELECT * FROM users_details where UserId ='$id'";
      $res1 = mysqli_query($con,$query1);
      $r1=mysqli_fetch_array($res1);


?>

          <?php
            
   
    date_default_timezone_set('Asia/Kolkata');
    $date = date('d-m-y h:i:s');  
    $id= $_SESSION['loggedUserId'];
     $bid=$_GET['bid'];
     $sql = mysqli_query($con, "SELECT room_book where BookingId=$bid ");
    while ($r6 = mysqli_fetch_array($sql)) 
    {
        $a=$r6['Amount'];
       // $i=$r6['pay_status'];
        //$i=$row['pstatus'];
       
    }
    $sql1="INSERT INTO `room_payment`(`UserId`, `BookingId`, `PaymentDate`, `Amount`, `Status`) VALUES ('$id','$bid','$date','$a','Paid')";
    mysqli_query($con,$sql1);
    if (headers_sent()) {
      ?>
    <script>
      alert("Paid Successfully");
      </script>
    <?php
      die('<script type="text/javascript">window.location.href="bill.php?id='.$bid.'" </script>');
    } else {
      header("location:bill.php?id=".$bid."");
      die();
    }   
  
?>
         
<?php 
}           

?>