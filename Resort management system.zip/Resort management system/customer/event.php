<?php include('include/header.php') ;
include('../include/dbConnect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<body>
<div class="container">
      <a class="navbar-brand "><b><h1>Available Events</h1></a></b>
</div>
<div class="row product-categorie-box">
    
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade show active" id="grid-view">
                                    <div class="row">
                                    <?php  
                                    $result = mysqli_query($con,"SELECT * FROM event_type INNER JOIN event_list ON event_type.EventTypeId=event_list.EventTypeId where Booking_status='Available'");
                                    while ($raw = mysqli_fetch_array($result)){ 
                                        ?>
                                        <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                                        <form method="post"  enctype="multipart/form-data" action="">
                                            <div class="products-single fix">
                                                <div class="box-img-hover">
                                                   <center>
                                                    <img src="../assets/picture/EventType/<?php echo $raw['EventImage']; ?>" class="img-fluid" alt="Image" style="height: 188px;width: 322px;">
                                    </center>
                                                </div>
                                                <div class="why-text">
                                                <h4 align="center"><?php echo $raw['EventType']; ?></h4>
                                                <h4 align="center">Rs.<?php echo $raw['Cost']; ?></h4>
                                                <h6 align="center"><?php echo $raw['Description']; ?></h6>
                                                <h6 align="center"><?php echo $raw['Booking_status']; ?></h6>
                                                    <input type="hidden" name="productid" value="<?php echo $raw['EventTypeId']; ?>"> 
                                                    <a class="nav-link"  href="eventbook.php?sid=<?php echo $raw['EventTypeId']; ?>" aria-selected="true" align="center">Book Now</a>
                                                </div>
                                            </div><br><br>
                                            </form>
                                        </div>
                                        <?php } ?>	
                                    </div>
                                </div>
                                
                                     
                             
                            </div>
                        </div>

</body>
</html>