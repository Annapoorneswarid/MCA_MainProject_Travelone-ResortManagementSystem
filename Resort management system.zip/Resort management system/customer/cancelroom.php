<?php
include('include/header.php');
include('../include/dbconnect.php');
$rid=$_GET['cid'];
$sql=mysqli_query($con,"SELECT * FROM `room_book` WHERE `BookingId`='$rid'"); 
$rows=mysqli_fetch_array($sql); 
$status=$rows['Status'];
if($status='Booked')
{
    $sql1=mysqli_query($con,"UPDATE `room_book` SET `Status`='Cancelled' WHERE  `BookingId`='$rid'"); 
    echo "<script> window.location.href='roomb.php';</script>";
}

?>