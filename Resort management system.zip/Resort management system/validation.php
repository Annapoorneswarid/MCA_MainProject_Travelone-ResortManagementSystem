<?php

include('include/functions.php');
session_start();

if(isset($_POST['user_login'])){

    $email=$_POST['email'];
    $password=$_POST['password'];
    $select_user="select * from  users_details where Email='$email' && Password ='$password'";
    $result=mysqli_query($con,$select_user) or die ('failed to query');
    $row=mysqli_fetch_array($result);
    
    if(($row['Email']==$email) && ($row['Password']==$password))
    {
        if($row['Email']=="admin"){

           // $_SESSION['r_id']=$row['Userid'];

            header("Location:./Admin_/admin_home.php");
        } 
        else 
        {
            header("Location:customer/index.php?");
        }

        $_SESSION['loggedUserName']=$row['FirstName'];
        $_SESSION['loggedUserId']=$row['UserId'];
       
        
            
    }
    else{
        $error="Invalid Username and Password !";
        error('login.php',$error);
    } 
}
?>